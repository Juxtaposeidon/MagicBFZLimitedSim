$(document).ready(function() {
    $('.slideshow').cycle({
    fx: 'fade',
    timeout:  2500
  });
});
